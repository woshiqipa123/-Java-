package com.mashibing.common.constant;

/**
 * @author zjw
 * @description
 */
public interface WebMasterConstants {

    /**
     * 将验证码基于这个key做存储
     */
    String KAPTCHA = "kaptcha";

    /**
     * 管理员角色
     */
    String ROOT = "管理员";


}
