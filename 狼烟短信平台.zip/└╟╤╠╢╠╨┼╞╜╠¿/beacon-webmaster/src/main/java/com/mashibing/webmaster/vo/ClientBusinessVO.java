package com.mashibing.webmaster.vo;

import lombok.Data;

/**
 * @author zjw
 * @description
 */
@Data
public class ClientBusinessVO {

    private Long id;

    private String corpname;
}
