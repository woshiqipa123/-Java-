package com.mashibing.strategy.util;

import com.mashibing.common.model.StandardSubmit;

import java.util.Map;

/**
 * 通道转换留的口子
 * @author zjw
 * @description
 */
public class ChannelTransferUtil {


    /**
     * 暂时啥都不做~~
     * @param submit
     * @param channel
     * @return
     */
    public static Map transfer(StandardSubmit submit,Map channel){
        // do nothing~
        return channel;
    }


}
